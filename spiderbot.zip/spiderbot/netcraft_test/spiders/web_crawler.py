#############################################
# Netcraft assignment 
#############################################

'''
Assignment: 
Implement a very simple web crawler with the following task.

Tasks:
1) Accept a single starting URL such as https://news.ycombinator.com as input.
2) Download the web page available at the input URL and extract URLs of other pages
linked to from the HTML source code.
3) Looking at the href attribute of tags to extract the links.
4) It should attempt to donwload each of those URLs in turn to find even more URLs,
then download those and so on.

Goals:
Ths program should stop after it has discovered 100 unique URLs and print one URL per
line as its output.
'''
import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import Rule, CrawlSpider
from ..items import URLsItem

class WebCrawlerSpider(CrawlSpider):
	# Name of the web crawler
	name = 'web_crawler'

	# A list of URLs to crawl with start URLs as base URLs
	# allowed_domains = ['news.ycombinator.com']
	start_urls = ['http://news.ycombinator.com/']

	# Use set container class to store unique URLs
	visited_url = set()

	# Only need to set the rule to extract link from extracted links
	rules = [
			Rule(
            	LinkExtractor(restrict_xpaths=[
                "*//div/a/@href",
                "*//li/a/@href"]),
            	callback='parse_items', follow=True)
			]

	'''Default parsing function to parse base URLs and retrieve the URLs of other webpage

	Args:
		response: HTML source code

	Returns:
		{URLs, Title}:  URLs and title
	'''
	def parse(self, response):
		'''Searching for news title by looking at the header with the 'title' and download the pages
		'''
		TITLE_BLOCK = '.athing'
		for title in response.css(TITLE_BLOCK):
			''' Append ::text to our css selector for the name and extract_first() will return the object
			 that match the title.css(NAME_SELECTOR) while the XPATH can use to extract the data from 
			 child nodes.
			'''
			LINK_SELECTOR = 'a[class="storylink"]::attr(href)'
			TITLE_SELECTOR = './/td/a/text()'
			extract_URL = title.css(LINK_SELECTOR).extract_first()
			extract_title = title.xpath(TITLE_SELECTOR).extract_first()

			# Some story link begin with item?id=
			if not (extract_URL.startswith('http://') or extract_URL.startswith('https://')):
				extract_URL = self.start_urls[0] + extract_URL

			# Add unvisited URL to set
			self.visited_url.add(extract_URL)
			print(len(self.visited_url))

			yield {
				'URLs': extract_URL,
				'Title': extract_title,
			}
		print(self.visited_url)

		# Passing each page to parse items to retrieve more links
		for url in self.visited_url:
			yield scrapy.Request(
				url,
				callback=self.parse_items
			)

		''' Crawl multiple page by finding the load more button and invoke the callback function if
		the next links exist.
		'''
		# NEXT_PAGE_SELECTOR = 'a[rel="next"]::attr(href)'
		# next_page = response.css(NEXT_PAGE_SELECTOR).extract_first()

		# # Invoke callback parse function 
		# if next_page:
		# 	yield scrapy.Request(
		# 		response.urljoin(next_page),
		# 		callback=self.parse
		# 	)

	'''Parsing the extracted links and retrieve more URLs	

	Args:
		response: HTML source code

	Returns:
		{URLs, Title}:  URLs and title
	'''
	def parse_items(self, response):
		title = response.xpath('./text()').extract_first()
		URL = response.xpath('./a/@href').extract_first()
		self.visited_url.add(URL)

		# Use URLs item to store url as an object
		URL_item = URLsItem()
		URL_item['title'] = title
		URL_item['URL'] = URL

		yield URL_item